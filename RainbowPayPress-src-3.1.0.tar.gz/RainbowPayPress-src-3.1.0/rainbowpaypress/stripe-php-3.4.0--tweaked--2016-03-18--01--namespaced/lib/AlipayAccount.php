<?php

namespace plugin_RainbowPayPress\Stripe;

class AlipayAccount extends ExternalAccount
{

}
