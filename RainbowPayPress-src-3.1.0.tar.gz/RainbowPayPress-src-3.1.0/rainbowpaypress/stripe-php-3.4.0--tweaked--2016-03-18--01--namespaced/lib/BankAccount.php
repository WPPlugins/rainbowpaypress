<?php

namespace plugin_RainbowPayPress\Stripe;

class BankAccount extends ExternalAccount
{

}
