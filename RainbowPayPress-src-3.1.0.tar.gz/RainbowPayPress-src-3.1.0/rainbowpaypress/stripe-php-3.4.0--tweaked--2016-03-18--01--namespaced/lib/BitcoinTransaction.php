<?php

namespace plugin_RainbowPayPress\Stripe;

class BitcoinTransaction extends ApiResource
{

}
