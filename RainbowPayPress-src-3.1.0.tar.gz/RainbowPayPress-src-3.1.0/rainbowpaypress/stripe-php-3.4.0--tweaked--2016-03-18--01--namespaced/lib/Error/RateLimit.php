<?php

namespace plugin_RainbowPayPress\Stripe\Error;

class RateLimit extends InvalidRequest
{
}
