<?php

namespace plugin_RainbowPayPress\Stripe\Error;

class Api extends Base
{
}
