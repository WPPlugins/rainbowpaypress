<?php

namespace plugin_RainbowPayPress\Stripe\Error;

class Authentication extends Base
{
}
