<?php

namespace plugin_RainbowPayPress\Stripe;

class Card extends ExternalAccount
{

}
